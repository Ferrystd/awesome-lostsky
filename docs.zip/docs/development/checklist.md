# 代码更新清单

按当前任务的改动类型勾选；不相关的项目无需运行，工作区已有差异不自动计入当前任务。测试范围及扩大条件以[测试须知](testing.md)为准。

## 每次代码改动

- [ ] 按[Changelog 写法](releasing.md#changelog)更新 `docs/changelog.md` 的“未发布”区，不修改已经发布的版本章节。
- [ ] 更新直接相关测试；输入、结构或示例变化时同步 fixture 和测试数据清理逻辑。
- [ ] 运行直接相关检查和 `git diff --check`，只记录实际结果。
- [ ] 长任务、上下文切换、委派或覆盖风险出现时，已按[工作区保护与阶段性暂存](contributing.md#staged-worktree-baseline)为通过直接验证的切片建立显式、可审查的暂存基线；未使用宽泛暂存，也未纳入或清空其他任务差异。
- [ ] 不手改 `www/`、生成 API 类型或 Service 字典；涉及对应源文件时必须运行生成命令。生成 API 类型和 Service 字典的差异必须保留；`www/` 可再生产物只验证生成成功，不纳入 Git。这里的“保留现有改动”仅指不得丢弃、回退或覆盖用户已有差异，不表示跳过生成。
- [ ] 新增或修改后台页面结构时已按[页面组件化方法](../design/admin/componentization.md)完成实施前盘点；达到阈值的模式已全量迁移并清理旧 CSS。
- [ ] 已按[封闭组件契约](../design/admin/componentization.md#closed-component-contract)确认唯一视觉所有者；页面和上层组件未使用 `:deep(.ls-*)`、视觉参数或样式透传进入公共组件内部，新增参数已满足真实变体准入条件。
- [ ] 涉及组件内部布局时已增加禁止父级穿透的源码守卫；涉及等宽、满宽、容器或溢出时已增加桌面与移动端的结构化 DOM 尺寸断言，未以组件截图代替自动验证。
- [ ] 用户截图或实时页面暴露的每个视觉缺陷已写成明确关系并断言实际控件几何；没有用外层容器存在、字段外壳顶部或生成预览 PNG 冒充对应问题的回归测试。
- [ ] 每个业务分组只有一个保存动作和一个原子批量提交；无修改时不可保存，查询刷新不覆盖脏草稿，提交期间继续编辑不会被误标为已保存，离开页面统一提示。
- [ ] 所有数字控件覆盖清空后的 `null`、非有限值、范围与金额平衡；提交前统一归一化，未对可空模型直接调用 `toFixed()`。写入结果会成为其他表单候选时已等待候选缓存刷新。
- [ ] 主查询、局部候选查询分别覆盖加载、错误、空与成功；错误不退化为空白内容或伪空候选，恢复动作不会重复提交写请求。
- [ ] 已有公共视觉原语时业务页面未直接使用第三方底层控件；淘汰的直用方式已全量迁移，并由源码契约禁止回归而不是保留宽泛白名单。

## 联动清单

| 改动 | 一并维护 | 至少运行 |
| --- | --- | --- |
| PHP | 直接相关测试 | `php -l <文件>`、相关 PHP 测试 |
| 路由、请求或响应 | 路由、控制器/服务、OpenAPI、调用方、测试 | `php tests/openapi_routes.php`、相关测试 |
| Service public 方法 | `docs/glossary/service.md` | `php think docs:services`；只校验时使用 `--check` |
| 模型、字段、约束或数据语义 | 模型/验证器、`sql/schema.sql`、日期补丁、OpenAPI、fixture | 执行补丁并只读验证、相关集成测试 |
| 枚举或权限字典 | 枚举/`PermissionDictionary`、验证、OpenAPI、前端选项、权限文档、测试 | `php tests/permission_gate.php`、相关测试 |
| OpenAPI | `docs/openapi/*.json`、调用方、生成 API 类型 | `php tests/openapi_routes.php`、`npm run typecheck`（包含类型生成） |
| 前端源码或构建配置 | 前端测试、路由别名、`www/` 构建验证 | `npm test`、`npm run typecheck`、按需 `npm run test:e2e`、`npm run build` |
| 测试 fixture 或演示数据 | 创建、断言、清理逻辑及关联 schema | 直接使用该数据的测试 |
| 媒体 | `frontend/media/manifest.json`、来源或许可证 | `npm run check:media`、`npm run build` |
| CORS、域名或静态交付 | 路由/CORS 文档、Nginx 模板、调用方 | `npm run check:cors`、按需 `npm run test:e2e`、`npm run build` |
| npm 依赖 | `package.json`、`package-lock.json` | `npm ci`、受影响测试与构建 |
| Composer 依赖 | `composer.json`、`composer.lock` | `composer validate`、`composer check-platform-reqs`、相关测试 |
| Wiki/文档 | 正文、链接；新增、改名或删除时同步 `zensical.toml` | `npm run build:docs` |
| 文档站依赖 | `docs/requirements.txt` | `npm run docs:setup`、`npm run build:docs` |
| 配置或部署模板 | `.env.example`、`deploy/`、运维文档 | 对应检查与部署验证 |

## 发布时

按[发布须知](releasing.md)统一核对版本、锁文件、Changelog、受跟踪生成物、全量测试和本地静态构建。

- 产品版本发布：更新版本文件，将“未发布”内容固化为 `vX.Y.Z`，同步 `docs/updates.md` 并创建同名附注标签。
- 产品预发布：版本文件更新为 `X.Y.Z-stage.N`，保留目标正式版本的“未发布”日志，不滚动 `docs/updates.md`，并创建同名 `vX.Y.Z-stage.N` 附注标签。
- 构建发布：产品版本文件保持不变，保留“未发布”日志并创建唯一的 `build-YYYYMMDD.N` 附注标签。
