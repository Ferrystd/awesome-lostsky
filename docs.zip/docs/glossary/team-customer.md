---
title: 团队顾客（Team Customer）
description: 团队的顾客实体，可关联真实用户。
tags: [glossary]
status: 已建页
aliases: [团队顾客, Team Customer]
---

# 团队顾客（Team Customer）

## 定义

团队顾客是团队维护的顾客实体；它可以与真实用户关联，但其业务身份独立于用户登录身份。

## 使用场景

顾客可用于订单、余额、交易和顾客资料等业务。真实用户在符合条件时可领取自己的顾客实体；其他实体也可在被授予权限后委托到顾客身份。

顾客可以有一个可变的当前归属实体 `assignee_entity_id`，候选仅限同团队的 Team、成员和虚拟实体。带 `ref=<entity-slug>` 的公开访问会在首次创建顾客时登记初始归属；顾客本人或具备 `team.customer.manage` 的后台实体可以改选或清空。订单和流水创建时把当时归属快照到 `sender_entity_id`，因此后来改归属不会改变历史业绩。

## 不包括什么

- 业务身份不依赖真实用户登录身份。
- 归属实体候选仅限同团队的 Team、成员与虚拟实体。

## 相关概念

- [Entity](entity.md)定义顾客作为当前业务主体的方式。
- [团队成员](team-member.md)是用户常用的另一种根身份。
- [Context](context.md)把当前顾客写入请求业务上下文。

## 来源与示例

身份关系见[实体身份与跨团队委托](../architecture/entity-authorization.md)，模型位于 `app/model/TeamCustomer.php`。例如，顾客身份可访问其订单与余额，而不是凭真实用户 ID 推断范围。
