---
title: 团队成员（Team Member）
description: 与真实用户关联的团队内成员实体。
tags: [glossary]
status: 已建页
aliases: [团队成员, Team Member]
---

# 团队成员（Team Member）

## 定义

团队成员是团队内与真实用户关联的成员实体，也是用户在团队业务中常用的根身份之一。

## 使用场景

用户可显式领取自己的有效成员身份，再通过获得的授权委托到其他实体。成员可以承载资料、角色及团队内业务职责。

## 不包括什么

- 不等于真实用户：同一用户可在不同团队拥有各自成员身份。
- 不承担登录与设备认证职责，认证仍以真实 `user` 为准。

## 相关概念

- [Entity](entity.md)说明成员作为业务主体的统一方式。
- [Slug](slug.md)用于成员的全局标识与精确授权。
- [团队顾客](team-customer.md)是另一种可关联用户的实体。

## 来源与示例

身份规则见[实体身份与跨团队委托](../architecture/entity-authorization.md)，模型位于 `app/model/TeamMember.php`。例如，用户进入团队后领取自己的成员实体，再以该实体管理被授予权限的资源。
