---
title: 权限与访问模型
description: 了解 Ability 与 Permission 的区别、Permission 的组成与通配规则、全量读取权限的边界，以及访问失败时如何定位。
---

# 权限与访问模型

LostSky 的访问结果不是由单一“管理员”开关决定。系统会依次确认登录和当前身份、团队归属、Ability、Permission、内容可见范围及业务状态。

每个 Ability 的作用、等级、有效期、查看兑换方式、缺失原因和降级行为，见[能力目录](abilities.md)。

## Ability 与 Permission 的区别

| 项目 | Ability | Permission |
| --- | --- | --- |
| 归属 | 团队 | 当前实体(Entity)的角色 |
| 作用 | 决定某项产品能力是否开通、等级和有效期 | 决定具体读取、创建、编辑、删除或管理动作 |
| 例子 | `transaction` 开通记账能力 | `transaction.write` 允许登记或编辑流水 |
| 谁能调整 | 具备 `admin.team.ability.write` 的 LostSky 平台管理员，或有服务器权限的平台运维；Team 界面不能直接授权 | 具备 `team.role.write` 的团队角色管理员 |
| 缺失提示 | `当前团队缺失能力(Ability): …` | `缺少权限(Permission): …` |

某操作同时要求两者时，二者必须同时满足。拥有全部 Permission 不会自动开通 Ability；团队开通 Ability 也不会把对应权限自动发给所有实体。

## Permission 如何计算

Permission 来自当前实体在目标团队中获得的全部角色，多个角色取并集。Permission 没有 deny 规则；任一角色包含所需键即可通过该项检查。

有些接口接受多个候选 Permission，满足任意一个即可。有些权限带 `*` 或具体 slug：

- `identity.member.*.assume`：可领取当前授权团队任意有效成员；
- `identity.member.alice.assume`：只可领取当前团队的 `@alice`；
- `chat.virtual.*.act`：可代表当前团队全部虚拟实体参与聊天；
- `chat.virtual.support-bot.act`：只可在 Chat 中代表 `@support-bot`。

通配权限只覆盖授予它的团队，不会扩散到其他团队。所有固定键和动态模式见[权限目录](permissions.md)。

## 全量读取不是页面门票

以下 Permission 表示扩大可读范围，不代表没有它就完全无法进入：

| Permission | 缺少时的基础范围 | 具备后的范围 |
| --- | --- | --- |
| `team.entity.read` | 有效、非 Customer 且团队内可见的实体 | 全部有效实体，包括 Customer 和团队内隐藏实体 |
| `team.member.read` | 有效且团队内可见的成员 | 完整成员管理集合，包括隐藏或封禁成员 |
| `team.document.read` | 当前实体按文档可见性可读的文档 | 当前团队全部文档 |
| `team.customer.read` | 当前归属实体只看到归属于自己的顾客 | 当前团队全部顾客 |

无权访问隐藏对象时，直接链接会返回“未找到”，而不是确认对象存在后再报无权。

页面标题区的主操作不会因为暂时缺少 Permission 而变成另一种灰色按钮或移动位置：入口仍保留同一图标、文字和主色来源，以灰绿色降权表示不可用；存在具体原因时，触发该入口会显示需要补齐的 Permission、Ability 或业务条件。

## 推荐的授权顺序

1. 先确认用户已经领取正确团队的实体身份。
2. 确认团队已开通任务所需 Ability（见[能力目录](abilities.md)）。
3. 创建职责清楚的角色，并保存完整 Permission 集合。
4. 把角色分配给需要执行任务的实体。
5. 用该实体重新进入任务页，验证读、写和失败恢复路径。

以下只是角色设计示例，不是系统自动创建的内置角色：

| 角色示例 | 常见 Permission |
| --- | --- |
| 内容维护 | `team.entity.profile.manage`、`team.document.read`、`file.read`；如需直接维护团队文件库，再授予 `file.upload` |
| 成员管理员 | `team.member.read`、`team.member.invite`、`team.member.update`、`team.member.remove` |
| 财务 | `transaction.read`、`transaction.write`、`transaction.report.read` |
| 顾客运营 | `team.customer.read`、`team.customer.manage`、`team.notice.send` |
| 发单运营 | `service.entitlement.grant`；我的流水、业绩和我的顾客无需 Team 全量读取 Permission |
| Chat 运营 | `chat.conversation.create`、`chat.group.manage`，以及所需虚拟实体的 `chat.virtual.<slug>.act` 权限 |

新团队会自动创建 owner 角色并给创建者取得管理所需权限。后续修改 owner 或其他高权限角色前，应先确保至少还有一个实体能够恢复角色配置。

## 访问失败时先判断哪一层

| 现象 | 更可能的原因 | 下一步 |
| --- | --- | --- |
| 被送到登录页 | 未登录、登录过期或设备会话被撤销 | 重新登录并返回原任务 |
| 被要求领取成员身份 | 当前没有实体身份 | 在 Account 确认目标团队并领取身份 |
| 提示身份属于其他团队 | 当前实体与地址团队不一致 | 确认切换；取消会保留原身份 |
| 提示 `Permission` | 当前实体的角色缺少具体授权键 | 联系团队角色管理员 |
| 提示 `Ability` | 团队未开通、等级不足或已过期 | 联系 LostSky 平台管理员 |
| 显示“未找到” | 对象无效、跨团队、被隐藏或链接错误 | 核对团队、slug/编号和对象状态 |
| 提示余额、配额或状态不允许 | 业务前置条件不满足 | 按页面提示充值、清理空间或等待状态变化 |

完整恢复步骤见[问题排查](troubleshooting.md)。
